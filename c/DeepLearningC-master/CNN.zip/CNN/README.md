C语言版本的CNN   
关于项目的具体说明可以参见个人CSDN博客tostq    
http://blog.csdn.net/tostq/article/category/6290467     
系列博客：编写C语言版本的卷积神经网络CNN  
Tips：  
由于MINST数据库文件太大了，所以没有包含在这个项目内，自行下载，将MINST四个文件分别解压放到Minst文件夹就可以了
